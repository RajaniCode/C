﻿using System;

namespace libfoo
{
    public class StringLibrary
    {
       public static string GetString() => "The quick brown fox jumps over the lazy dog"; 
    }
}
