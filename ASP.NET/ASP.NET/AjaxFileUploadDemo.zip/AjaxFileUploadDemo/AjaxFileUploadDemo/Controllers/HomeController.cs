﻿using System;
using System.IO;
using System.Web;
// Install-Package Microsoft.AspNet.Mvc -Version 3.0.20105.1
using System.Web.Mvc;

namespace AjaxFileUploadDemo.Controllers
{
	public class HomeController : Controller
	{
		public ActionResult Index()
		{
			return View();
		}

		// public WrappedJsonResult UploadImage(HttpPostedFileWrapper imageFile)

		[HttpPost]
		public WrappedJsonResult UploadFile(HttpPostedFileWrapper fileName)
		{
			if (fileName == null || fileName.ContentLength == 0)
			{
				return new WrappedJsonResult
				{
					Data = new
					{
						IsValid = false,
						Message = "No file was uploaded.",
						// ImagePath = string.Empty
						FilePath = string.Empty
					}
				};
			}

			// var fileName = String.Format("{0}.jpg", Guid.NewGuid().ToString());
			// var fileName = String.Format("{0}", Guid.NewGuid().ToString());
			var name = fileName.FileName;
			// var imagePath = Path.Combine(Server.MapPath(Url.Content("~/Uploads")), fileName);
			var filePath = Path.Combine(Server.MapPath(Url.Content("~/Uploads")), (string)name);

			fileName.SaveAs(filePath);

			return new WrappedJsonResult
            {
				Data = new
				{
					IsValid = true,
					Message = string.Empty,
					// ImagePath = Url.Content(String.Format("~/Uploads/{0}", fileName))
					FilePath = Url.Content(string.Format("~/Uploads/{0}", (object)fileName))
				}
			};
		}
	}
}
