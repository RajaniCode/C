﻿namespace ArdalisRating
{
    public class NullLogger : ILogger
    {
        public void Log(string message)
        {
        }
    }
}
