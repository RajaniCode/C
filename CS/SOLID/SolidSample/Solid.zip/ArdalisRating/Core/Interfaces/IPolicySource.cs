﻿namespace ArdalisRating
{
    public interface IPolicySource
    {
        string GetPolicyFromSource();
    }
}
