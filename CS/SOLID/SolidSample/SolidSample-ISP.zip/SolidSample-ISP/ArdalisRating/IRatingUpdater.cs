﻿namespace ArdalisRating
{
    public interface IRatingUpdater
    {
        void UpdateRating(decimal rating);
    }
}
