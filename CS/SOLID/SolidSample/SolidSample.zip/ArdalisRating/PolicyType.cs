﻿using System;

namespace ArdalisRating
{

    public enum PolicyType
    {
        Life = 0,
        Land = 1,
        Auto = 2
    }
}
