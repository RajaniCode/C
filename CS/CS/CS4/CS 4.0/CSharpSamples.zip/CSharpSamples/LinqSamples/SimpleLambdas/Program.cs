﻿// Copyright © Microsoft Corporation.  All Rights Reserved.
// This code released under the terms of the 
// Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
//
//Copyright (C) Microsoft Corporation.  All rights reserved.

using System;
using System.Collections.Generic;
using System.Linq;

// See the ReadMe.html for additional information
class Program
{
    static void Main()
    {
        Samples.Sample1();        
        Console.ReadLine();
    }
}
