def welcome(name):
	return "Hello '" + name + "' from IronPython"