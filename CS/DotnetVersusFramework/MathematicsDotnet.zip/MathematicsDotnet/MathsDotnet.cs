﻿namespace MathematicsDotnet
{
    public class MathsDotnet
    {
        public int AddTwoIntegers(int x, int y) => x + y;
    }
}