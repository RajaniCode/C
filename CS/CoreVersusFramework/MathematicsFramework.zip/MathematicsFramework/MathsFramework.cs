﻿namespace MathematicsFramework
{
    public class MathsFramework
    {
        public int AddTwoIntegers(int x, int y) => x + y;
    }
}
