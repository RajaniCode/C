﻿namespace MathematicsCore
{
    public class MathsCore
    {
        public int AddTwoIntegers(int x, int y) => x + y;
    }
}
